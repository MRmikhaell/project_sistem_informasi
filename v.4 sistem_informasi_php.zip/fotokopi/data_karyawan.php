<?php 
require 'header.php';
// require 'db.php';

// Mengambil data barang
$dataKaryawan = getKaryawan();
?>

<!-- _____________________________________________________________________MODAL_____________________________________________________________________ -->

<!-- MODAL HAPUS -->
<div class="modal fade" id="konfirmasiModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header border-bottom-danger">
        <h5 class="modal-title" id="exampleModalLabel">Konfirmasi Hapus</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        Apakah Anda Yakin Menghapus Data Ini?
      </div>
      <div class="modal-footer">
        <button type="button" id="btnHapus" class="btn btn-icon-split btn-round btn-success">
            <span class="icon text-white-50">
                <img src="img/check.png" alt="Icon" style="vertical-align: middle; margin-right: 5px;"  width="20" height="20">
            </span>
            <span class="text"><b>Ya</b></span>
        </button>
        <button type="button" class="btn btn-icon-split btn-round btn-danger" data-dismiss="modal">
            <span class="icon text-white-50">
                <img src="img/cancel.png" alt="Icon" style="vertical-align: middle; margin-right: 5px;"  width="20" height="20">
            </span>
            <span class="text"><b>Tidak</b></span>
        </button>
      </div>
    </div>
  </div>
</div>
<!-- MODAL HAPUS END -->

<!-- MODAL TAMBAH -->
<div class="modal fade" id="tambahModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header border-bottom-primary">
        <h5 class="modal-title" id="exampleModalLabel">Tambah Data Karyawan</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
        <form action="tambah_data_karyawan.php" id="myForm" method="POST">
            <div class="modal-body">    
                <div class="form-floating mb-4">
                    <label for="Nama">Nama Karyawan</label>
                    <input type="text" class="form-control" name="nama_karyawan" placeholder="">
                </div>

                <div class="form-floating mb-4">
                    <label for="Harga">No Telp</label>
                    <input type="text" class="form-control" name="no_telp" placeholder="">
                </div>
                
                <div class="form-floating mb-4">
                    <label for="Harga">Alamat</label>
                    <input type="text" class="form-control" name="alamat" placeholder="">
                </div>

                <div class="form-floating mb-4">
                    <label for="Harga">Username</label>
                    <input type="text" class="form-control" name="username" placeholder="">
                </div>

                <div class="form-floating mb-4">
                    <label for="Harga">Password</label>
                    <input type="text" class="form-control" name="password" placeholder="">
                </div>
                
                <div class="form-floating mb-4">
                    <label for="Harga">Role</label><br>
                    <div class="d-inline custom-control custom-radio">
                        <input type="radio" id="pemilik" name="role" class="custom-control-input" value="pemilik">
                        <label style="margin-right: 5px;" class="custom-control-label" for="pemilik">Pemilik</label>
                    </div>
                    <div class="d-inline custom-control custom-radio">
                        <input type="radio" id="admin" name="role" class="custom-control-input" value="admin">
                        <label class="custom-control-label" for="admin">Admin</label>
                    </div>
                </div>


            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-icon-split btn-success btn-round">
                    <span class="icon text-white-50">
                        <img src="img/check.png" alt="Icon" style="vertical-align: middle; margin-right: 5px;"  width="20" height="20">
                    </span>
                    <span class="text"><b>Kirim</b></span>
                </button>
                <button type="reset" onclick="resetForm()" class="btn btn-danger btn-icon-split btn-round">
                    <span class="icon text-white-50">
                        <img src="img/cancel.png" alt="Icon" style="vertical-align: middle; margin-right: 5px;"  width="20" height="20">
                    </span>
                    <span class="text"><b>Ulang</b></span>
                </button>
            </div>
        </form>
    </div>
  </div>
</div>
<!-- MODAL TAMBAH END -->

<!-- MODAL EDIT -->
<div class="modal fade" id="tambahModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header border-bottom-primary">
        <h5 class="modal-title" id="exampleModalLabel">Tambah Data Barang</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
        <form action="tambah_data_barang.php" id="myForm" method="POST">
            <div class="modal-body">    
                <div class="form-floating mb-4">
                    <label for="Nama">Nama Barang</label>
                    <input type="text" class="form-control" name="nama_barang" placeholder="">
                </div>

                <input type="text" style="display: none;" class="form-control" name="jumlah_barang" value="0">

                <div class="form-floating mb-4">
                    <label for="Harga">Harga Barang</label>
                    <input type="text" class="form-control" name="harga_barang" placeholder="">
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-icon-split btn-success btn-round">
                    <span class="icon text-white-50">
                        <img src="img/check.png" alt="Icon" style="vertical-align: middle; margin-right: 5px;"  width="20" height="20">
                    </span>
                    <span class="text"><b>Kirim</b></span>
                </button>
                <button type="reset" onclick="resetForm()" class="btn btn-danger btn-icon-split btn-round">
                    <span class="icon text-white-50">
                        <img src="img/cancel.png" alt="Icon" style="vertical-align: middle; margin-right: 5px;"  width="20" height="20">
                    </span>
                    <span class="text"><b>Ulang</b></span>
                </button>
            </div>
        </form>
    </div>
  </div>
</div>
<!-- MODAL EDIT END -->

<!-- _____________________________________________________________________MODAL END_____________________________________________________________________ -->

<!-- Content Row -->
  <!-- Begin Page Content -->
  <div class="container-fluid">

<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">
            <a data-toggle="modal" data-target="#tambahModal" class="btn btn-primary btn-icon-split btn-round">
                <span class="icon text-white-50">
                    <img src="img/add.png" alt="Icon" style="vertical-align: middle; margin-right: 5px;"  width="27" height="27">
                </span>
                <span class="text"><b>Tambah Data Karyawan</b></span>
            </a>
            <!-- <a href="tambah_data_barang.php">
                <button style="display: flex; align-items: center;" class="btn btn-round btn-primary">
                    <!-- <img src="" style="vertical-align: middle; margin-right : 5px;"> Tambah Data Barang -->
                    <!-- <img src="img/add.png" alt="Icon" style="vertical-align: middle; margin-right: 5px;"  width="27" height="27"> Tambah Data Barang -->
                <!-- </button> -->
            <!-- </a> -->
        </h6>
        
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Kayawan</th>
                        <th>No Telp</th>
                        <th>Alamat</th>
                        <th>Username</th>
                        <th>Password</th>
                        <th>Role</th>
                        <th style="width: 250px;">Aksi</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>No</th>
                        <th>Nama Kayawan</th>
                        <th>No Telp</th>
                        <th>Alamat</th>
                        <th>Username</th>
                        <th>Password</th>
                        <th>Role</th>
                        <th style="width: 250px;">Aksi</th>
                    </tr>
                </tfoot>
                <tbody>
                    <?php
                    // Menampilkan data barang
                        $i = 0;
                        foreach ($dataKaryawan as $karyawan) {
                            $i += 1;
                    ?>
                    <tr>
                        <td><?php echo $i; ?></td>
                        <td><?php echo $karyawan['nama_karyawan']; ?></td>
                        <td><?php echo $karyawan['no_telp']; ?></td>
                        <td><?php echo $karyawan['alamat']; ?></td>
                        <td><?php echo $karyawan['username']; ?></td>
                        <td><?php echo $karyawan['password']; ?></td>
                        <td><?php echo $karyawan['level']; ?></td>
                        <td>
                            <!-- <a href="tambah_data_barang.php" class="btn btn-info btn-icon-split btn-round">
                                <span class="icon text-white-50">
                                    <img src="img/file.png" alt="Icon" style="margin-right: 5px;"  width="25" height="25">
                                </span>
                                <span class="text">Detail</span>
                            </a> -->
                            <a href="#" onclick="editKaryawan(this);" id_karyawan="<?php echo $karyawan['id_karyawan']; ?>" class="btn btn-sm btn-warning btn-icon-split btn-round">
                                <span class="icon text-white-50">
                                    <img src="img/editing.png" alt="Icon" style="margin-right: 5px;"  width="21" height="21">
                                </span>
                                <span class="text"><b>Edit</b></span>
                            </a>
                            <a href="#" data-toggle="modal" data-target="#konfirmasiModal" isi="<?php echo $karyawan['id_karyawan']; ?>" onclick="hapusData(this);" class="btn btn-sm btn-danger btn-icon-split btn-round">
                                <span class="icon text-white-50">
                                    <img src="img/delete.png" alt="Icon" style="margin-right: 5px;" width="21" height="21">
                                </span>
                                <span class="text"><b>Hapus</b></span>
                            </a>

                        </td>
                    </tr>
                    <?php
                        }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

</div>
<!-- /.container-fluid -->


</div>
<!-- End of Main Content -->

<script>
function editKaryawan(button) {
    var idKaryawan = button.getAttribute("id_karyawan");
    var url = "edit_data_karyawan.php?id_karyawan=" + idKaryawan;
    window.location.href = url;
}
function resetForm() {
  document.getElementById("myForm").reset();
}
function tambahData(button) {
  var dataId = button.getAttribute("isi");

  // Menampilkan modal konfirmasi
  var modal = document.getElementById("konfirmasiModal");
  modal.style.display = "block";

  // Mengatur tindakan ketika tombol "Hapus" diklik
  var btnHapus = document.getElementById("btnHapus");
  btnHapus.onclick = function() {
    // Buat objek XMLHttpRequest atau gunakan fetch API jika Anda lebih memilih
    var xhr = new XMLHttpRequest();

    // Tetapkan fungsi callback untuk menangani respons dari server
    xhr.onreadystatechange = function() {
      if (xhr.readyState === XMLHttpRequest.DONE) {
        if (xhr.status === 200) {
        //   alert(xhr.responseText); // Tampilkan pesan sukses dari server
          location.reload(); // Memuat ulang halaman setelah berhasil menghapus data
        } else {
          alert('Terjadi kesalahan: ' + xhr.status); // Tampilkan pesan kesalahan dari server
        }
      }
    };

    // Konfigurasi dan kirim permintaan AJAX ke file PHP yang akan menangani penghapusan data
    xhr.open('POST', 'delete_data.php', true);
    xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    xhr.send('data_id=' + dataId);

    // Menutup modal konfirmasi
    modal.style.display = "none";
  };

  return false; // Batalkan aksi href default pada hyperlink
}
function hapusData(button) {
  var dataId = button.getAttribute("isi");

  // Menampilkan modal konfirmasi
  var modal = document.getElementById("konfirmasiModal");
  modal.style.display = "block";

  // Mengatur tindakan ketika tombol "Hapus" diklik
  var btnHapus = document.getElementById("btnHapus");
  btnHapus.onclick = function() {
    // Buat objek XMLHttpRequest atau gunakan fetch API jika Anda lebih memilih
    var xhr = new XMLHttpRequest();

    // Tetapkan fungsi callback untuk menangani respons dari server
    xhr.onreadystatechange = function() {
      if (xhr.readyState === XMLHttpRequest.DONE) {
        if (xhr.status === 200) {
        //   alert(xhr.responseText); // Tampilkan pesan sukses dari server
          location.reload(); // Memuat ulang halaman setelah berhasil menghapus data
        } else {
          alert('Terjadi kesalahan: ' + xhr.status); // Tampilkan pesan kesalahan dari server
        }
      }
    };

    // Konfigurasi dan kirim permintaan AJAX ke file PHP yang akan menangani penghapusan data
    xhr.open('POST', 'delete_data_karyawan.php', true);
    xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    xhr.send('data_id=' + dataId);

    // Menutup modal konfirmasi
    modal.style.display = "none";
  };

  return false; // Batalkan aksi href default pada hyperlink
}
</script>


<?php
require 'footer.php';
?>