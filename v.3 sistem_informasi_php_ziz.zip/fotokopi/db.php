<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "fotokopi";

// Membuat koneksi
$conn = new mysqli($servername, $username, $password, $dbname);

// Memeriksa koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Fungsi untuk mengambil data barang
function getBarang() {
    global $conn;
    
    $query = "SELECT * FROM barang";
    $result = $conn->query($query);

    $data = array();
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
    }

    return $data;
}

// Fungsi untuk mengambil data barang
function getKaryawan() {
    global $conn;
    
    $query = "SELECT * FROM karyawan";
    $result = $conn->query($query);

    $data = array();
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
    }

    return $data;
}

// Fungsi untuk mengambil data barang
function getBarangMasuk() {
    global $conn;
    
    // $query = "SELECT * FROM barang_masuk";
    $query = "SELECT *
          FROM barang_masuk bm
          INNER JOIN barang b ON bm.id_barang = b.id_barang 
          INNER JOIN karyawan k ON bm.id_karyawan = k.id_karyawan";

    $result = $conn->query($query);

    $data = array();
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
    }

    return $data;
}

function insertBarang($namaBarang, $hargaBarang, $jumlahBarang) {
    global $conn;

    $query = "INSERT INTO barang (nama_barang, harga_barang, jumlah_barang) VALUES ('$namaBarang', '$hargaBarang', '$jumlahBarang')";
    $result = $conn->query($query);

    if ($result === false) {
        die("Error: " . $conn->error);
    } else {
        echo '<script>window.location.href = "data_barang.php";</script>'; // Alihkan ke halaman data_barang.php
    }

    // Pesan sukses atau tindakan selanjutnya setelah berhasil memasukkan data

    $conn->close();
}

function insertKaryawan($namaKaryawan, $notelpKaryawan, $alamatKaryawan, $usernameKaryawan, $passwordKaryawan, $roleKaryawan) {
    global $conn;

    $query = "INSERT INTO karyawan (nama_karyawan, no_telp, alamat, username, password, level) VALUES ('$namaKaryawan', '$notelpKaryawan', '$alamatKaryawan', '$usernameKaryawan', '$passwordKaryawan', '$roleKaryawan')";
    $result = $conn->query($query);

    if ($result === false) {
        die("Error: " . $conn->error);
    } else {
        echo '<script>window.location.href = "data_karyawan.php";</script>'; // Alihkan ke halaman data_barang.php
    }

    // Pesan sukses atau tindakan selanjutnya setelah berhasil memasukkan data

    $conn->close();
}

function insertBarangMasuk($id_barang, $jumlah_pertambahan, $tanngal_pertambahan, $id_karyawan) {
    global $conn;

    $query1 = "INSERT INTO barang_masuk (id_barang, jumlah_pertambahan, tanngal_pertambahan, id_karyawan) VALUES ('$id_barang', '$jumlah_pertambahan', '$tanngal_pertambahan', '$id_karyawan')";
    $query2 = "UPDATE barang SET jumlah_barang = jumlah_barang + $jumlah_pertambahan WHERE id_barang = '$id_barang'";
    
    $result = $conn->multi_query($query1 . ";" . $query2);

    if ($result === false) {
        die("Error: " . $conn->error);
    } else {
        echo '<script>window.location.href = "data_barang_masuk.php";</script>'; // Alihkan ke halaman data_barang.php
    }

    // Pesan sukses atau tindakan selanjutnya setelah berhasil memasukkan data

    $conn->close();
}

function updateStokBarang($jumlah_pertambahan) {
    global $conn;

    $query = "UPDATE barang SET jumlah_barang = jumlah_barang + $jumlah_pertambahan";
    $result = $conn->query($query);

    // Pesan sukses atau tindakan selanjutnya setelah berhasil memasukkan data

    $conn->close();
}

?>
