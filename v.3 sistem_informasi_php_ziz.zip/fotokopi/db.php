<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "fotokopi";

// Membuat koneksi
$conn = new mysqli($servername, $username, $password, $dbname);

// Memeriksa koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Fungsi untuk mengambil data barang
function getBarang() {
    global $conn;
    
    $query = "SELECT * FROM barang";
    $result = $conn->query($query);

    $data = array();
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
    }

    return $data;
}

function insertBarang($namaBarang, $hargaBarang, $jumlahBarang) {
    global $conn;

    $query = "INSERT INTO barang (nama_barang, harga_barang, jumlah_barang) VALUES ('$namaBarang', '$hargaBarang', '$jumlahBarang')";
    $result = $conn->query($query);

    if ($result === false) {
        die("Error: " . $conn->error);
    } else {
        echo '<script>window.location.href = "data_barang.php";</script>'; // Alihkan ke halaman data_barang.php
    }

    // Pesan sukses atau tindakan selanjutnya setelah berhasil memasukkan data

    $conn->close();
}


?>
