<?php
// Mengambil ID data yang akan dihapus dari permintaan POST
$dataId = $_POST['data_id'];

// Melakukan koneksi ke database
$koneksi = mysqli_connect("localhost", "root", "", "fotokopi");

// Memeriksa koneksi database
if (mysqli_connect_errno()) {
    echo "Koneksi database gagal: " . mysqli_connect_error();
    exit();
}

// Membuat query SQL untuk menghapus data
$query = "DELETE FROM barang WHERE id_barang = '$dataId'";

// Menjalankan query untuk menghapus data
if (mysqli_query($koneksi, $query)) {
    echo "Data berhasil dihapus.";
} else {
    echo "Gagal menghapus data: " . mysqli_error($koneksi);
}

// Menutup koneksi database
mysqli_close($koneksi);
?>
