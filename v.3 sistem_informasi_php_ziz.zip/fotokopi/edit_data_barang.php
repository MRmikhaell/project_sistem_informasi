<?php 
require 'header.php';
// error_reporting(0);
// Mengambil ID barang dari parameter query string
$idBarang = $_GET['id_barang'];

// Melakukan koneksi ke database
$koneksi = mysqli_connect("localhost", "root", "", "fotokopi");

// Memeriksa koneksi database
if (mysqli_connect_errno()) {
    echo "Koneksi database gagal: " . mysqli_connect_error();
    exit();
}

// Mengecek apakah form pengeditan telah disubmit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Mengambil data yang diubah dari form
    $namaBarang = $_POST['nama_barang'];
    $jumlahBarang = $_POST['jumlah_barang'];
    $hargaBarang = $_POST['harga_barang'];

    // Melakukan validasi data (sesuaikan dengan kebutuhan Anda)

    // Mengupdate data barang ke database
    $query = "UPDATE barang SET nama_barang = '$namaBarang', jumlah_barang = '$jumlahBarang', harga_barang = '$hargaBarang' WHERE id_barang = '$idBarang'";

    if (mysqli_query($koneksi, $query)) {
        mysqli_close($koneksi);
        echo '<script>window.location.href = "data_barang.php";</script>'; // Alihkan ke halaman data_barang.php
    } else {
        echo "Gagal memperbarui data: " . mysqli_error($koneksi);
    }
} else {
    // Menampilkan form pengeditan data
    $query = "SELECT * FROM barang WHERE id_barang = '$idBarang'";
    $result = mysqli_query($koneksi, $query);
    $barang = mysqli_fetch_assoc($result);

    // Menampilkan form pengeditan dengan data barang yang telah ada
?>

<!-- Content Row -->
  <!-- Begin Page Content -->
  <div class="container-fluid">
    <form action="" method="POST">
      <div class="form-floating mb-4">
        <label for="Nama">Nama Barang</label>
        <input type="text" class="form-control" name="nama_barang" placeholder="" value="<?php echo $barang['nama_barang']; ?>">
      </div>

      <input type="number" style="display: none;" class="form-control" name="jumlah_barang" value="<?php echo $barang['jumlah_barang']; ?>">

      <div class="form-floating mb-4">
        <label for="Harga">Harga Barang</label>
        <input type="number" class="form-control" name="harga_barang" placeholder="" value="<?php echo $barang['harga_barang']; ?>">
      </div>

      <input type="submit" class="btn btn-success" value="Kirim">
      <button class="btn btn-danger">Hapus</button>
    </form>
</div>


<?php
}
// Menutup koneksi database
// mysqli_close($koneksi);
require 'footer.php';
?>