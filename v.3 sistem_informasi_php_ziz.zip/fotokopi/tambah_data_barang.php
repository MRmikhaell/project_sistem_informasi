<?php 
require 'header.php';
// Sembunyikan semua pesan error
error_reporting(0);
?>

<!-- Content Row -->
  <!-- Begin Page Content -->
  <div class="container-fluid">
    <form action="tambah_data_barang.php" id="myForm" method="POST">
      <div class="form-floating mb-4">
        <label for="Nama">Nama Barang</label>
        <input type="text" class="form-control" name="nama_barang" placeholder="">
      </div>

      <input type="number" style="display: none;" class="form-control" name="jumlah_barang" value="0">

      <div class="form-floating mb-4">
        <label for="Harga">Harga Barang</label>
        <input type="number" class="form-control" name="harga_barang" placeholder="">
      </div>

      <button type="submit" class="btn btn-primary btn-icon-split btn-success" data-dismiss="modal">
        <span class="icon text-white-50">
            <img src="img/check.png" alt="Icon" style="vertical-align: middle; margin-right: 5px;"  width="20" height="20">
        </span>
        <span class="text"><b>Kirim</b></span>
      </button>
      <button type="reset" onclick="resetForm()" class="btn btn-danger btn-icon-split btn-success" data-dismiss="modal">
        <span class="icon text-white-50">
            <img src="img/cancel.png" alt="Icon" style="vertical-align: middle; margin-right: 5px;"  width="20" height="20">
        </span>
        <span class="text"><b>Ulang</b></span>
      </button>
    </form>
</div>

<script>
function resetForm() {
  document.getElementById("myForm").reset();
}
</script>
<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $namaBarang = $_POST['nama_barang'];
  $jumlahBarang = $_POST['jumlah_barang'];
  $hargaBarang = $_POST['harga_barang'];
  insertBarang($namaBarang, $hargaBarang, $jumlahBarang);
}
// echo "Tes : ". $hargaBarang;


require 'footer.php';
?>