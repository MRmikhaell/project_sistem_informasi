<?php 
require 'header.php';
// require 'db.php';

// Mengambil data barang
$dataBarang = getBarang();
?>

<!-- Content Row -->
  <!-- Begin Page Content -->
  <div class="container-fluid">

<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">
            <a href="tambah_data_barang.php" class="btn btn-primary btn-icon-split btn-round">
                <span class="icon text-white-50">
                    <img src="img/add.png" alt="Icon" style="vertical-align: middle; margin-right: 5px;"  width="27" height="27">
                </span>
                <span class="text">Tambah Data Barang</span>
            </a>
            <!-- <a href="tambah_data_barang.php">
                <button style="display: flex; align-items: center;" class="btn btn-round btn-primary">
                    <!-- <img src="" style="vertical-align: middle; margin-right : 5px;"> Tambah Data Barang -->
                    <!-- <img src="img/add.png" alt="Icon" style="vertical-align: middle; margin-right: 5px;"  width="27" height="27"> Tambah Data Barang -->
                <!-- </button> -->
            <!-- </a> -->
        </h6>
        
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Barang></th>
                        <th>Qty</th>
                        <th>Harga</th>
                        <th style="width: 250px;">Aksi</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>No</th>
                        <th>Nama Barang</th>
                        <th>Qty</th>
                        <th>Harga</th>
                        <th style="width: 250px;">Aksi</th>
                    </tr>
                </tfoot>
                <tbody>
                    <?php
                    // Menampilkan data barang
                        $i = 0;
                        foreach ($dataBarang as $barang) {
                            $i += 1;
                    ?>
                    <tr>
                        <td><?php echo $i; ?></td>
                        <td><?php echo $barang['nama_barang']; ?></td>
                        <td><?php echo $barang['jumlah_barang']; ?></td>
                        <td><?php echo $barang['harga_barang']; ?></td>
                        <td>
                            <!-- <a href="tambah_data_barang.php" class="btn btn-info btn-icon-split btn-round">
                                <span class="icon text-white-50">
                                    <img src="img/file.png" alt="Icon" style="margin-right: 5px;"  width="25" height="25">
                                </span>
                                <span class="text">Detail</span>
                            </a> -->
                            <a href="#" onclick="editBarang(this);" id_barang="<?php echo $barang['id_barang']; ?>" class="btn btn-warning btn-icon-split btn-round">
                                <span class="icon text-white-50">
                                    <img src="img/editing.png" alt="Icon" style="margin-right: 5px;"  width="23" height="23">
                                </span>
                                <span class="text">Edit</span>
                            </a>
                            <a href="#" isi="<?php echo $barang['id_barang']; ?>" onclick="hapusData(this);" class="btn btn-danger btn-icon-split btn-round">
                                <span class="icon text-white-50">
                                    <img src="img/delete.png" alt="Icon" style="margin-right: 5px;" width="23" height="23">
                                </span>
                                <span class="text">Hapus</span>
                            </a>

                        </td>
                    </tr>
                    <?php
                        }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

</div>
<!-- /.container-fluid -->


</div>
<!-- End of Main Content -->

<script>
function hapusData(button) {
    var dataId = button.getAttribute("isi");

    if (confirm("Apakah Anda yakin ingin menghapus data ini?")) {
        // Buat objek XMLHttpRequest atau gunakan fetch API jika Anda lebih memilih
        var xhr = new XMLHttpRequest();

        // Tetapkan fungsi callback untuk menangani respons dari server
        xhr.onreadystatechange = function() {
            if (xhr.readyState === XMLHttpRequest.DONE) {
                if (xhr.status === 200) {
                    alert(xhr.responseText); // Tampilkan pesan sukses dari server
                    location.reload();
                } else {
                    alert('Terjadi kesalahan: ' + xhr.status); // Tampilkan pesan kesalahan dari server
                }
            }
        };

        // Konfigurasi dan kirim permintaan AJAX ke file PHP yang akan menangani penghapusan data
        xhr.open('POST', 'delete_data.php', true);
        xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
        xhr.send('data_id=' + dataId);
    }
}
function editBarang(button) {
    var idBarang = button.getAttribute("id_barang");
    var url = "edit_data_barang.php?id_barang=" + idBarang;
    window.location.href = url;
}
</script>


<?php
require 'footer.php';
?>