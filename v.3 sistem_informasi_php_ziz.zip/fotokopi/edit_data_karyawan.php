<?php 
require 'header.php';
// error_reporting(0);
// Mengambil ID barang dari parameter query string
$idKaryawan = $_GET['id_karyawan'];

// Melakukan koneksi ke database
$koneksi = mysqli_connect("localhost", "root", "", "fotokopi");

// Memeriksa koneksi database
if (mysqli_connect_errno()) {
    echo "Koneksi database gagal: " . mysqli_connect_error();
    exit();
}

// Mengecek apakah form pengeditan telah disubmit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Mengambil data yang diubah dari form
    $namaKaryawan = $_POST['nama_karyawan'];
    $notelpKaryawan = $_POST['no_telp'];
    $alamatKaryawan = $_POST['alamat'];
    $usernameKaryawan = $_POST['username'];
    $passwordKaryawan = $_POST['password'];
    $roleKaryawan = $_POST['role'];

    // Melakukan validasi data (sesuaikan dengan kebutuhan Anda)

    // Mengupdate data barang ke database
    $query = "UPDATE karyawan SET 
    nama_karyawan = '$namaKaryawan', no_telp = '$notelpKaryawan', alamat = '$alamatKaryawan', 
    username = '$usernameKaryawan', password = '$passwordKaryawan', level = '$roleKaryawan' 
    WHERE id_karyawan = '$idKaryawan'";

    if (mysqli_query($koneksi, $query)) {
        mysqli_close($koneksi);
        echo '<script>window.location.href = "data_karyawan.php";</script>'; // Alihkan ke halaman data_barang.php
    } else {
        echo "Gagal memperbarui data: " . mysqli_error($koneksi);
    }
} else {
    // Menampilkan form pengeditan data
    $query = "SELECT * FROM karyawan WHERE id_karyawan = '$idKaryawan'";
    $result = mysqli_query($koneksi, $query);
    $karyawan = mysqli_fetch_assoc($result);

    // Menampilkan form pengeditan dengan data barang yang telah ada
?>

<!-- Content Row -->
  <!-- Begin Page Content -->
  <div class="container-fluid">
    <form id="myForm" method="POST">  
                <div class="form-floating mb-4">
                    <label for="Nama">Nama Karyawan</label>
                    <input type="text" class="form-control" value="<?php echo $karyawan['nama_karyawan']; ?>" name="nama_karyawan" placeholder="">
                </div>

                <div class="form-floating mb-4">
                    <label for="Harga">No Telp</label>
                    <input type="text" class="form-control" value="<?php echo $karyawan['no_telp']; ?>" name="no_telp" placeholder="">
                </div>
                
                <div class="form-floating mb-4">
                    <label for="Harga">Alamat</label>
                    <input type="text" class="form-control" value="<?php echo $karyawan['alamat']; ?>" name="alamat" placeholder="">
                </div>

                <div class="form-floating mb-4">
                    <label for="Harga">Username</label>
                    <input type="text" class="form-control" value="<?php echo $karyawan['username']; ?>" name="username" placeholder="">
                </div>

                <div class="form-floating mb-4">
                    <label for="Harga">Password</label>
                    <input type="text" class="form-control" value="<?php echo $karyawan['password']; ?>" name="password" placeholder="">
                </div>
                
                <div class="form-floating mb-4">
                    <label for="Harga">Role</label><br>
                    <div class="d-inline custom-control custom-radio">
                        <input type="radio" id="pemilik" name="role" class="custom-control-input" <?php if ($karyawan['level'] == 'pemilik') echo 'checked'; ?> value="pemilik">
                        <label style="margin-right: 5px;" class="custom-control-label" for="pemilik">Pemilik</label>
                    </div>
                    <div class="d-inline custom-control custom-radio">
                        <input type="radio" id="admin" name="role" class="custom-control-input" <?php if ($karyawan['level'] == 'admin') echo 'checked'; ?> value="admin">
                        <label class="custom-control-label" for="admin">Admin</label>
                    </div>
                </div>
                <button type="submit" class="btn btn-icon-split btn-success btn-round">
                    <span class="icon text-white-50">
                        <img src="img/check.png" alt="Icon" style="vertical-align: middle; margin-right: 5px;"  width="20" height="20">
                    </span>
                    <span class="text"><b>Kirim</b></span>
                </button>
                <button type="reset" onclick="resetForm()" class="btn btn-danger btn-icon-split btn-round">
                    <span class="icon text-white-50">
                        <img src="img/cancel.png" alt="Icon" style="vertical-align: middle; margin-right: 5px;"  width="20" height="20">
                    </span>
                    <span class="text"><b>Ulang</b></span>
                </button>
        </form>
</div>


<?php
}
// Menutup koneksi database
// mysqli_close($koneksi);
require 'footer.php';
?>