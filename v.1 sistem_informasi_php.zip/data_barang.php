<?php 
require 'header.php';
?>

<!-- Content Row -->
  <!-- Begin Page Content -->
  <div class="container-fluid">

<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary"><button class="btn btn-primary">Tambah Data</button></h6>
        
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Kode Nama</th>
                        <th>Nama Barang</th>
                        <th>Qty</th>
                        <th>Harga</th>
                        <th>Detail</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>No</th>
                        <th>Kode Nama</th>
                        <th>Nama Barang</th>
                        <th>Qty</th>
                        <th>Harga</th>
                        <th>Detail</th>
                        <th>Aksi</th>
                    </tr>
                </tfoot>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td>koo1</td>
                        <td>Pensil</td>
                        <td>27</td>
                        <td>27.000</td>
                        <td><button class="btn btn-info">Detail</button></td>
                        <td>
                            <button class="btn btn-warning">Edit</button>
                            <button class="btn btn-danger">Hapuss</button>
                        </td>
                    </tr>
                    <tr>
                        <td>2</td>
                        <td>koo1</td>
                        <td>Pensil</td>
                        <td>27</td>
                        <td>27.000</td>
                        <td><button class="btn btn-info">Detail</button></td>
                        <td>
                            <button class="btn btn-warning">Edit</button>
                            <button class="btn btn-danger">Hapuss</button>
                        </td>
                    </tr>
                    <tr>
                        <td>3</td>
                        <td>koo1</td>
                        <td>Pensil</td>
                        <td>27</td>
                        <td>27.000</td>
                        <td><button class="btn btn-info">Detail</button></td>
                        <td>
                            <button class="btn btn-warning">Edit</button>
                            <button class="btn btn-danger">Hapuss</button>
                        </td>
                    </tr>
                    <tr>
                        <td>4</td>
                        <td>koo1</td>
                        <td>Pensil</td>
                        <td>27</td>
                        <td>27.000</td>
                        <td><button class="btn btn-info">Detail</button></td>
                        <td>
                            <button class="btn btn-warning">Edit</button>
                            <button class="btn btn-danger">Hapuss</button>
                        </td>
                    </tr>
                    <tr>
                        <td>5</td>
                        <td>koo1</td>
                        <td>Pensil</td>
                        <td>27</td>
                        <td>27.000</td>
                        <td><button class="btn btn-info">Detail</button></td>
                        <td>
                            <button class="btn btn-warning">Edit</button>
                            <button class="btn btn-danger">Hapuss</button>
                        </td>
                    </tr>
                    <tr>
                        <td>6</td>
                        <td>koo1</td>
                        <td>Pensil</td>
                        <td>27</td>
                        <td>27.000</td>
                        <td><button class="btn btn-info">Detail</button></td>
                        <td>
                            <button class="btn btn-warning">Edit</button>
                            <button class="btn btn-danger">Hapuss</button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

</div>
<!-- /.container-fluid -->


</div>
<!-- End of Main Content -->

<?php
require 'footer.php';
?>