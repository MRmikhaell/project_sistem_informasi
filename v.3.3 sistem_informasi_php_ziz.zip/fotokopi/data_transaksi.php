<?php 
require 'header.php';
?>

<!-- Content Row -->
  <!-- Begin Page Content -->
  <div class="container-fluid">

<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
    <h6 class="m-0 font-weight-bold text-primary"><a href="tambah_data_transaksi.php"><button class="btn btn-primary">Tambah Data Transaksi</button></a></h6>
        
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Kode Transaksi</th>
                        <th>Kode Barang</th>
                        <th>Nama Barang</th>
                        <th>Tanggal Terjual</th>
                        <th>Qty</th>
                        <th>Detail</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>No</th>
                        <th>Kode Transaksi</th>
                        <th>Kode Barang</th>
                        <th>Nama Barang</th>
                        <th>Qty</th>
                        <th>Harga</th>
                        <th>Detail</th>
                    </tr>
                </tfoot>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td>1231uoc1</td>
                        <td>koo1</td>
                        <td>Pensil</td>
                        <td>27/02/2003</td>
                        <td>28</td>
                        <td><button class="btn btn-info">Detail</button></td>
                    </tr>
                    <tr>
                        <td>2</td>
                        <td>1231uoc1</td>
                        <td>koo1</td>
                        <td>Pensil</td>
                        <td>27/02/2003</td>
                        <td>22</td>
                        <td><button class="btn btn-info">Detail</button></td>
                    </tr>
                    <tr>
                        <td>3</td>
                        <td>1231uoc1</td>
                        <td>koo1</td>
                        <td>Pensil</td>
                        <td>27/02/2003</td>
                        <td>21</td>
                        <td><button class="btn btn-info">Detail</button></td>
                    </tr>
                    <tr>
                        <td>4</td>
                        <td>1231uoc1</td>
                        <td>koo1</td>
                        <td>Pensil</td>
                        <td>27/02/2003</td>
                        <td>274</td>
                        <td><button class="btn btn-info">Detail</button></td>
                    </tr>
                    <tr>
                        <td>5</td>
                        <td>1231uoc1</td>
                        <td>koo1</td>
                        <td>Pensil</td>
                        <td>27/02/2003</td>
                        <td>274</td>
                        <td><button class="btn btn-info">Detail</button></td>
                    </tr>
                    <tr>
                        <td>6</td>
                        <td>1231uoc1</td>
                        <td>koo1</td>
                        <td>Pensil</td>
                        <td>27/02/2003</td>
                        <td>22</td>
                        <td><button class="btn btn-info">Detail</button></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

</div>
<!-- /.container-fluid -->


</div>
<!-- End of Main Content -->

<?php
require 'footer.php';
?>