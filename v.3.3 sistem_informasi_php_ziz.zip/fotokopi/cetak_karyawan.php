
<?php 


require 'header.php';
$dataKaryawan = getKaryawan();

 ?>

<body>

            <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              
            </div>
            <div class="card-body">
                <h3 class="m-0 font-weight-bold text-success" align="center">Fotocopy Admis Copy Center</h3>
                <h4 class="m-0 font-weight-bold text-success" align="center">Dekat Unikom</h4>
                <h6 class="m-0 font-weight-bold text-success" align="center">Jalan Astana Dipatiukur No. 26 Bandung</h6>
                <br><br><hr>
                <h4 class="m-0 font-weight-bold text-success" align="center">Data Karyawan</h4>
                <br><br>
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <tr>
                      <th>ID Karyawan</th>
                      <th>Nama Karyawan</th>
                      <th>No. Telepon</th>
                      <th>Alamat</th>
                      <th>Username</th>
                      <th>Level</th>
                    </tr>
                  
                  <?php
                  #require 'db.php';
                  #$sql=mysqli_query($conn, "select * from barang");
                  #while ($data=mysqli_fetch_array($sql)) {
                
                  ?>
                  <tbody>
                    <!-- <tr> 
                      <td><?php # echo $data['id_petugas']; ?></td>
                      <td><?php # echo $data['nama_petugas']; ?></td>
                      <td><?php # echo $data['username']; ?></td>
                  
                      <td><?php # echo $data['telp']; ?></td>
                      
                    </tr>   -->

                    <?php
                    // Menampilkan data barang
                        $i = 0;
                        foreach ($dataKaryawan as $karyawan) {
                            $i += 1;
                    ?>
                    <tr>
                        <td><?php echo $i; ?></td>
                        <td><?php echo $karyawan['nama_karyawan']; ?></td>
                        <td><?php echo $karyawan['no_telp']; ?></td>
                        <td><?php echo $karyawan['alamat']; ?></td>
                        <td><?php echo $karyawan['username']; ?></td>
                        <td><?php echo $karyawan['level']; ?></td>

                  </tbody>
                <?php } ?>
                </table>
              </div>
              <br><br>
              <h6 class="m-0 font-weight-bold text-primary" align="right">Bandung, <?php echo date('d M Y'); ?></h6>
              <br><br>
               <h6 class="m-0 font-weight-bold text-primary" align="right">Pemilik,</h6>
                <br><br><br><br>
                <h6 class="m-0 font-weight-bold text-primary" align="right"><?php echo $_SESSION['nama']; ?></h6>
            </div>
          </div>
  <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.4/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-match-height@0.7.2/dist/jquery.matchHeight.min.js"></script>
    <script src="assets/js/main.js"></script>

    <!--  Chart js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@2.7.3/dist/Chart.bundle.min.js"></script>

    <!--Chartist Chart-->
    <script src="https://cdn.jsdelivr.net/npm/chartist@0.11.0/dist/chartist.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartist-plugin-legend@0.6.2/chartist-plugin-legend.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/jquery.flot@0.8.3/jquery.flot.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/flot-pie@1.0.0/src/jquery.flot.pie.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/flot-spline@0.0.1/js/jquery.flot.spline.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/simpleweather@3.1.0/jquery.simpleWeather.min.js"></script>
    <script src="assets/js/init/weather-init.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/moment@2.22.2/moment.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@3.9.0/dist/fullcalendar.min.js"></script>
    <script src="assets/js/init/fullcalendar-init.js"></script>

   <script src="https://cdn.jsdelivr.net/npm/jquery@2.2.4/dist/jquery.min.js"></script>
    <!--Local Stuff-->
 
</body>
</html>